==============================================
  📱 你的 App 工程已生成（v2 · WebView 壳）
==============================================

📁 工程位置
/storage/emulated/0/xxss/小蓝工作区/App/

🎨 目录结构（只有 5 个文件，看得懂！）
  App/
    README.txt          ← 本文件
    app/
      src/main/
        AndroidManifest.xml    应用清单
        java/com/example/simpleapp/
          MainActivity.java    WebView 壳（不用改）
        res/values/
          strings.xml          应用名字
        assets/
          index.html           ★ 你的界面（改这里）

🔧 怎么打包成 APK
────────────────────────────────
方式 A（推荐）：走 GitHub Actions 云端出包
  1. 注册 GitHub（github.com）
  2. 建一个 Private 仓库，比如 my-app
  3. 加 .github/workflows/build.yml
  4. 把 App 目录整个上传到仓库
  5. GitHub 自动编译，去 Actions → Artifacts 下载 APK

方式 B：用 AIDE 编辑器本地编译
  1. AIDE 打开 App 目录
  2. 顶部菜单 → Build APK
  3. 产物在 build/outputs/apk/ 下

⚠️ 注意：手机上本地编译可能失败
  - 原因：aapt2 是 x86_64，手机是 aarch64，跑不动
  - 解决：优先用 GitHub Actions（免费）

🎨 想改界面？改 index.html
────────────────────────────────
打开 app/assets/index.html，直接用 HTML/CSS/JS 写页面。
改完点保存，重新 Build APK 就能看到效果。

🎨 想改 App 名字？改 strings.xml
────────────────────────────────
app/src/main/res/values/strings.xml
<string name="app_name">改成你想要的名字</string>

🎨 想改包名？改 2 处
────────────────────────────────
1. AndroidManifest.xml 的 package="com.example.simpleapp"
2. MainActivity.java 开头的 package com.example.simpleapp;
改包名会让老数据丢失。

💾 数据存在哪
────────────────────────────────
localStorage 存在 WebView 沙箱里。
⚠️ 卸载 App 会清空 localStorage！
⚠️ 网页版和 APK 版数据不互通。
⚠️ 数据多了（>5MB）可能写入失败，请提供导出/导入功能。

🆘 下一步做什么
────────────────────────────────
1. 打开 index.html，把里面的文字改成你自己的
2. 想加功能？让 Operit 帮你写 HTML/JS
3. 打包 APK 时遇到问题？让 Operit 帮你配 GitHub Actions

==============================================