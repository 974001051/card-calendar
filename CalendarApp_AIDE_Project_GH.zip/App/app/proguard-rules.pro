# 空 proguard 规则，预留
# -keep class com.example.simpleapp.** { *; }
